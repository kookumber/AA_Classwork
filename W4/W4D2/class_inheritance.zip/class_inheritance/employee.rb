class Employee

    attr_reader :name, :title, :salary, :boss

    def initialize(name, title, salary, boss)
        @name = name
        @title = title
        @salary = salary
        @boss = boss
    end

    def return_bonus(multiplier) #that's an int
        return @salary * multiplier
    end

    

end