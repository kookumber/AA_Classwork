class Game

    def initialize()
        @player_1 = Player.new("Q")
        @player_2 = Player.new("D")

        @fragment = ""
        
    end

end