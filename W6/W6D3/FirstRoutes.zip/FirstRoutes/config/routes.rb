Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  # resource :users

  # get 'users', to: 'users#index'
  # get 'users/new/:id', to: 'users#new'
  # get 'users/:id', to: 'users#show'
  # post 'users', to: 'users#create'
  # delete 'users/:id', to: 'users#destroy'
  # patch 'users/:id', to: 'users#update'

  resources :users, except:[:edit]
  resources :artworks, only:[:create, :destroy, :show, :update, :new]
  resources :artwork_shares, only:[:create, :destroy, :index]
  resources :comments, only:[:create, :destroy]
  
  get 'users/:artist_id/artworks', to: 'artworks#index'
  
  get 'users/:commenter_id/comments', to: 'comments#index'
  get 'artworks/:artwork_id/comments', to: 'comments#index'
  get 'comments', to: 'comments#index'
  
end
