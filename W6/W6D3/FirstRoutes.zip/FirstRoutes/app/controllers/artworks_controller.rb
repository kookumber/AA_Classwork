class ArtworksController < ApplicationController
    def show
        render json: Artwork.find(params[:id])
    end
    
    def index
        artist_id = params[:artist_id]
        artwork_shared_views = Artwork.select(:id, :title, :image_url, :artist_id).joins(:views).where('artwork_shares.viewer_id = (?)', artist_id)
        artwork_owned = Artwork.select(:id, :title, :image_url, :artist_id).where('artist_id = (?)', artist_id)
        # render json: Artwork.find_by(artist_id: params[:artist_id])
        # render json: Artwork.select(:id, :title, :image_url, :artist_id).joins(:views).where('artist_id = (?)', artist_id)
        render json: artwork_shared_views + artwork_owned
        
    end

    def destroy
        artworks = Artwork.find(params[:id])
        artworks.destroy
        redirect_to artworks_url
    end

    def create
        artworks = Artwork.new(artwork_params)
        if artworks.save
            render json: artworks
        else
            render json: artworks.errors.full_messages, status: :unprocessable_entity
        end
    end

    def new
        render plain: "I'm not new!"
    end

    def update
        # debugger
        artwork = Artwork.find(params[:id])

        if artwork.update(artwork_params)
            redirect_to artworks_url(artwork)
        else
            render json: artwork.errors.full_messages, status: :unprocessable_entity
        end
            
    end

    private

    def artwork_params

        params.require(:artwork).permit(:title, :image_url, :artist_id)
    end
end
