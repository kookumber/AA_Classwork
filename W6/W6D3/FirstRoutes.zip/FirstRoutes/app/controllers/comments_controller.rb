class CommentsController < ApplicationController

    def index
        comment = Comment.all
        commenter_id = params[:commenter_id]
        artwork_id = params[:artwork_id]
        
        if commenter_id
            render json: Comment.select(:body, :artwork_id, :commenter_id).where('commenter_id = ?', commenter_id)
        elsif artwork_id
            render json: Comment.select(:body, :artwork_id, :commenter_id).where('artwork_id = ?', artwork_id)
        else
            render json: comment
        end
        # render plain: "I'm in the index action!"
    end

    def create
        comment = Comment.new(comment_params)
        if comment.save
            render json: comment
        else
            render json: comment.errors.full_messages, status: :unprocessable_entity
        end
    end

    def destroy
        comment = Comment.find(params[:id])
        comment.destroy
        render json: comment
    end

    def comment_params
        params.require(:comment).permit(:commenter_id, :artwork_id, :body)
    end
end
