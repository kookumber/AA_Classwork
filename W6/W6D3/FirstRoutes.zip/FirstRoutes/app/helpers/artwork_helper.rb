module ArtworkHelper
end
