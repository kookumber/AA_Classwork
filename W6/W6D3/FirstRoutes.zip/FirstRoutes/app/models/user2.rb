# == Schema Information
#
# Table name: user2s
#
#  id         :bigint           not null, primary key
#  name       :string           not null
#  email      :string
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class User2 < ApplicationRecord
    
end
