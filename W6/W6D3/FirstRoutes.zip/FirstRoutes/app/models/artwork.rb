# == Schema Information
#
# Table name: artworks
#
#  id         :bigint           not null, primary key
#  title      :string           not null
#  image_url  :string           not null
#  artist_id  :integer          not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
class Artwork < ApplicationRecord

    validates :artist_id, uniqueness: { scope: :title, message: "shouldn't have more than one artwork of the same title"}

    belongs_to :artist,
        primary_key: :id,
        foreign_key: :artist_id,
        class_name: :User,
        dependent: :destroy

    has_many :views,
        primary_key: :id,
        foreign_key: :artwork_id,
        class_name: :ArtworkShare

    has_many :shared_viewers,
        through: :views,
        source: :viewer

    has_many :comments,
        primary_key: :id,
        foreign_key: :artwork_id,
        class_name: :Comment
end
